﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vsichko
{
    class Calculator
    {
        public double AddNumbers(double val1, double val2)
        { return val1 + val2; }

        public double DellNumbers(double val1, double val2)
        { return val1 - val2; }

        public double HalfNumbers(double val1, double val2)
        { return val1 / val2; }

        public double DoubleNumbers(double val1, double val2)
        { return val1 * val2; }

    }
}
