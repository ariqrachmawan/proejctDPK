﻿namespace Vsichko
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.uPR1ZAD3PROSTKALKULATORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.uPR2ZAD2BEZBUTONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.uPR2ZAD5KLIENTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uPR2ZAD6SCROLLBARSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sITKSTFORMULQRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uPR3ZAD1FORMULISTEPENYVANEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uPR3ZAD2OSIGYROVKIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zaKontrolnoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.moqKontrolno1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mAGAZINToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kALENDARToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lIHVAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(604, 24);
            this.menuStrip2.TabIndex = 0;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uPR1ZAD3PROSTKALKULATORToolStripMenuItem,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.uPR2ZAD2BEZBUTONToolStripMenuItem,
            this.toolStripMenuItem5,
            this.uPR2ZAD5KLIENTToolStripMenuItem,
            this.uPR2ZAD6SCROLLBARSToolStripMenuItem,
            this.sITKSTFORMULQRToolStripMenuItem,
            this.uPR3ZAD1FORMULISTEPENYVANEToolStripMenuItem,
            this.uPR3ZAD2OSIGYROVKIToolStripMenuItem,
            this.zaKontrolnoToolStripMenuItem,
            this.moqKontrolno1ToolStripMenuItem,
            this.mAGAZINToolStripMenuItem,
            this.kALENDARToolStripMenuItem,
            this.lIHVAToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(70, 20);
            this.toolStripMenuItem1.Text = "ZADACHI";
            // 
            // uPR1ZAD3PROSTKALKULATORToolStripMenuItem
            // 
            this.uPR1ZAD3PROSTKALKULATORToolStripMenuItem.Name = "uPR1ZAD3PROSTKALKULATORToolStripMenuItem";
            this.uPR1ZAD3PROSTKALKULATORToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.uPR1ZAD3PROSTKALKULATORToolStripMenuItem.Text = "UPR 1, ZAD 3, PROST KALKULATOR";
            this.uPR1ZAD3PROSTKALKULATORToolStripMenuItem.Click += new System.EventHandler(this.uPR1ZAD3PROSTKALKULATORToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(281, 22);
            this.toolStripMenuItem3.Text = "UPR 2, ZAD 1, S BUTON";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(281, 22);
            this.toolStripMenuItem4.Text = "UPR 2, ZAD 1, BEZ BUTON";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // uPR2ZAD2BEZBUTONToolStripMenuItem
            // 
            this.uPR2ZAD2BEZBUTONToolStripMenuItem.Name = "uPR2ZAD2BEZBUTONToolStripMenuItem";
            this.uPR2ZAD2BEZBUTONToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.uPR2ZAD2BEZBUTONToolStripMenuItem.Text = "UPR 2, ZAD 2, BEZ BUTON";
            this.uPR2ZAD2BEZBUTONToolStripMenuItem.Click += new System.EventHandler(this.uPR2ZAD2BEZBUTONToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(281, 22);
            this.toolStripMenuItem5.Text = "UPR 2, ZAD 3, BEZ BUTON";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // uPR2ZAD5KLIENTToolStripMenuItem
            // 
            this.uPR2ZAD5KLIENTToolStripMenuItem.Name = "uPR2ZAD5KLIENTToolStripMenuItem";
            this.uPR2ZAD5KLIENTToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.uPR2ZAD5KLIENTToolStripMenuItem.Text = "UPR 2, ZAD 5, KLIENT";
            this.uPR2ZAD5KLIENTToolStripMenuItem.Click += new System.EventHandler(this.uPR2ZAD5KLIENTToolStripMenuItem_Click);
            // 
            // uPR2ZAD6SCROLLBARSToolStripMenuItem
            // 
            this.uPR2ZAD6SCROLLBARSToolStripMenuItem.Name = "uPR2ZAD6SCROLLBARSToolStripMenuItem";
            this.uPR2ZAD6SCROLLBARSToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.uPR2ZAD6SCROLLBARSToolStripMenuItem.Text = "UPR 2, ZAD 6, SCROLLBARS";
            this.uPR2ZAD6SCROLLBARSToolStripMenuItem.Click += new System.EventHandler(this.uPR2ZAD6SCROLLBARSToolStripMenuItem_Click);
            // 
            // sITKSTFORMULQRToolStripMenuItem
            // 
            this.sITKSTFORMULQRToolStripMenuItem.Name = "sITKSTFORMULQRToolStripMenuItem";
            this.sITKSTFORMULQRToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.sITKSTFORMULQRToolStripMenuItem.Text = "SIT/KST FORMULQR";
            this.sITKSTFORMULQRToolStripMenuItem.Click += new System.EventHandler(this.sITKSTFORMULQRToolStripMenuItem_Click);
            // 
            // uPR3ZAD1FORMULISTEPENYVANEToolStripMenuItem
            // 
            this.uPR3ZAD1FORMULISTEPENYVANEToolStripMenuItem.Name = "uPR3ZAD1FORMULISTEPENYVANEToolStripMenuItem";
            this.uPR3ZAD1FORMULISTEPENYVANEToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.uPR3ZAD1FORMULISTEPENYVANEToolStripMenuItem.Text = "UPR 3, ZAD 1, FORMULI, STEPENYVANE";
            this.uPR3ZAD1FORMULISTEPENYVANEToolStripMenuItem.Click += new System.EventHandler(this.uPR3ZAD1FORMULISTEPENYVANEToolStripMenuItem_Click);
            // 
            // uPR3ZAD2OSIGYROVKIToolStripMenuItem
            // 
            this.uPR3ZAD2OSIGYROVKIToolStripMenuItem.Name = "uPR3ZAD2OSIGYROVKIToolStripMenuItem";
            this.uPR3ZAD2OSIGYROVKIToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.uPR3ZAD2OSIGYROVKIToolStripMenuItem.Text = "UPR 3, ZAD 2, OSIGYROVKI";
            this.uPR3ZAD2OSIGYROVKIToolStripMenuItem.Click += new System.EventHandler(this.uPR3ZAD2OSIGYROVKIToolStripMenuItem_Click);
            // 
            // zaKontrolnoToolStripMenuItem
            // 
            this.zaKontrolnoToolStripMenuItem.Name = "zaKontrolnoToolStripMenuItem";
            this.zaKontrolnoToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.zaKontrolnoToolStripMenuItem.Text = "Za kontrolno";
            this.zaKontrolnoToolStripMenuItem.Click += new System.EventHandler(this.zaKontrolnoToolStripMenuItem_Click);
            // 
            // moqKontrolno1ToolStripMenuItem
            // 
            this.moqKontrolno1ToolStripMenuItem.Name = "moqKontrolno1ToolStripMenuItem";
            this.moqKontrolno1ToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.moqKontrolno1ToolStripMenuItem.Text = "Moq Kontrolno 1";
            this.moqKontrolno1ToolStripMenuItem.Click += new System.EventHandler(this.moqKontrolno1ToolStripMenuItem_Click);
            // 
            // mAGAZINToolStripMenuItem
            // 
            this.mAGAZINToolStripMenuItem.Name = "mAGAZINToolStripMenuItem";
            this.mAGAZINToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.mAGAZINToolStripMenuItem.Text = "MAGAZIN";
            this.mAGAZINToolStripMenuItem.Click += new System.EventHandler(this.mAGAZINToolStripMenuItem_Click);
            // 
            // kALENDARToolStripMenuItem
            // 
            this.kALENDARToolStripMenuItem.Name = "kALENDARToolStripMenuItem";
            this.kALENDARToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.kALENDARToolStripMenuItem.Text = "KALENDAR";
            this.kALENDARToolStripMenuItem.Click += new System.EventHandler(this.kALENDARToolStripMenuItem_Click);
            // 
            // lIHVAToolStripMenuItem
            // 
            this.lIHVAToolStripMenuItem.Name = "lIHVAToolStripMenuItem";
            this.lIHVAToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.lIHVAToolStripMenuItem.Text = "LIHVA";
            this.lIHVAToolStripMenuItem.Click += new System.EventHandler(this.lIHVAToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(604, 562);
            this.Controls.Add(this.menuStrip2);
            this.MainMenuStrip = this.menuStrip2;
            this.Name = "Form1";
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem zADACHIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uPR1ZAD3KALKULATORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uPR2ZAD1SBUTONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uPR2ZAD1BEZBUTONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uPR2ZAD2BEZBUTONCELZIIFARENHAITToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uPR2ZAD3BEZBUTONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uPR2ZAD5KLIENTIToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem uPR1ZAD3PROSTKALKULATORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem uPR2ZAD2BEZBUTONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem uPR2ZAD5KLIENTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uPR2ZAD6SCROLLBARSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sITKSTFORMULQRToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uPR3ZAD1FORMULISTEPENYVANEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uPR3ZAD2OSIGYROVKIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zaKontrolnoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem moqKontrolno1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mAGAZINToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kALENDARToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lIHVAToolStripMenuItem;
    }
}

