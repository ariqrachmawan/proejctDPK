﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vsichko
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void uPR1ZAD3PROSTKALKULATORToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            Form4 frm = new Form4();
            frm.Show();
        }

        private void uPR2ZAD2BEZBUTONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 frm = new Form5();
            frm.Show();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            Form6 frm = new Form6();
            frm.Show();
        }

        private void uPR2ZAD5KLIENTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form7 frm = new Form7();
            frm.Show();
        }

        private void uPR2ZAD6SCROLLBARSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form8 frm = new Form8();
            frm.Show();
        }

        private void sITKSTFORMULQRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form9 frm = new Form9();
            frm.Show();
        }

        private void uPR3ZAD1FORMULISTEPENYVANEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form10 frm = new Form10();
            frm.Show();
        }

        private void uPR3ZAD2OSIGYROVKIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form11 frm = new Form11();
            frm.Show();
        }

        private void zaKontrolnoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form12 frm = new Form12();
            frm.Show();

        }

        private void moqKontrolno1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form13 frm = new Form13();
            frm.Show();

        }

        private void mAGAZINToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form14 frm = new Form14();
            frm.Show();
        }

        private void kALENDARToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form15 frm = new Form15();
            frm.Show();
        }

        private void lIHVAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form16 frm = new Form16();
            frm.Show();
        }

        

    }
}
